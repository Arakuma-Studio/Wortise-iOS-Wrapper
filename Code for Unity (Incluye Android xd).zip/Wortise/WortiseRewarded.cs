﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif

public class WortiseRewarded
{
    #if UNITY_ANDROID
    private static AndroidJavaObject activity
    {
        get
        {
            return WortiseSdk.activity;
        }
    }
    
    private AndroidJavaObject rewardedAd;
            
    public bool IsAvailable
    {
        get
        {
            return rewardedAd.Call<bool>("isAvailable");
        }
    }
    
    public bool IsDestroyed
    {
        get
        {
            return rewardedAd.Call<bool>("isDestroyed");
        }
    }

    public bool IsShowing
    {
        get
        {
            return rewardedAd.Call<bool>("isShowing");
        }
    }
    
    public event Action OnClicked;
    public event Action<WortiseReward> OnCompleted;
    public event Action OnDismissed;
    public event Action OnFailedToLoad;
    public event Action OnFailedToShow;
    public event Action OnImpression;
    public event Action OnLoaded;
    public event Action OnShown;

    
    public WortiseRewarded(string adUnitId)
    {
        rewardedAd = new AndroidJavaObject("com.wortise.ads.rewarded.RewardedAd", activity, adUnitId);
        rewardedAd.Call("setListener", new RewardedAdListener(this));
    }

    public void Destroy()
    {
        rewardedAd.Call("destroy");
    }
    
    public void LoadAd()
    {
        rewardedAd.Call("loadAd");
    }
    
    public void ShowAd()
    {
        if (activity != null) {
            rewardedAd.Call("showAd", activity);
        }
    }
    
    class RewardedAdListener : AndroidJavaProxy
    {
        private WortiseRewarded rewardedAd;


        public RewardedAdListener(WortiseRewarded rewardedAd) : base("com.wortise.ads.rewarded.RewardedAd$Listener")
        {
            this.rewardedAd = rewardedAd;
        }
        
        public void onRewardedClicked(AndroidJavaObject ad)
        {
            if (rewardedAd.OnClicked != null) {
                rewardedAd.OnClicked();
            }
        }

        public void onRewardedCompleted(AndroidJavaObject ad, AndroidJavaObject reward)
        {
            if (reward == null || rewardedAd.OnCompleted == null) {
                return;
            }

            int    amount  = reward.Call<int>   ("getAmount");
            string label   = reward.Call<string>("getLabel");
            bool   success = reward.Call<bool>  ("getSuccess");

            WortiseReward r = new WortiseReward(success, label, amount);

            rewardedAd.OnCompleted(r);
        }

        public void onRewardedDismissed(AndroidJavaObject ad)
        {
            if (rewardedAd.OnDismissed != null) {
                rewardedAd.OnDismissed();
            }
        }

        public void onRewardedFailedToLoad(AndroidJavaObject ad, AndroidJavaObject error)
        {
            Debug.Log("Failed to load rewarded ad!");
            Debug.Log("error: " + error.Call<string>("getMessage"));

            if (rewardedAd.OnFailedToLoad != null) {
                rewardedAd.OnFailedToLoad();
            }
        }

        public void onRewardedFailedToShow(AndroidJavaObject ad, AndroidJavaObject error)
        {
            if (rewardedAd.OnFailedToShow != null) {
                rewardedAd.OnFailedToShow();
            }
        }

        public void onRewardedImpression(AndroidJavaObject ad)
        {
            if (rewardedAd.OnImpression != null) {
                rewardedAd.OnImpression();
            }
        }

        public void onRewardedLoaded(AndroidJavaObject ad)
        {
            if (rewardedAd.OnLoaded != null) {
                rewardedAd.OnLoaded();
            }
        }

        public void onRewardedShown(AndroidJavaObject ad)
        {
            if (rewardedAd.OnShown != null) {
                rewardedAd.OnShown();
            }
        }
    }
    #endif

    #if UNITY_IOS
    public WortiseRewarded(string adID, SwiftDelegates.CallbackDelegate onLoaded,
        SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onFailedToShow,
        SwiftDelegates.CallbackDelegate onDismissed, SwiftDelegates.CallbackDelegate onCompletedAd)
    {
        LoadRewardedAd(adID, onLoaded, onFailedToLoad, onFailedToShow, onDismissed, onCompletedAd);
    }

    [DllImport("__Internal")]
    private static extern void LoadRewardedAd(string adID, SwiftDelegates.CallbackDelegate onLoaded,
        SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onFailedToShow,
        SwiftDelegates.CallbackDelegate onDismissed, SwiftDelegates.CallbackDelegate onCompletedAd);

    public void ShowAd()
    {
        UnityIOSPause.Pause();
        ShowRewarded();
    }

    [DllImport("__Internal")]
    private static extern void ShowRewarded();

    public bool IsAvailable
    {
        get
        {
            return IsRewardedAvailable() == 1;
        }
    }

    [DllImport("__Internal")]
    private static extern int IsRewardedAvailable();

    #endif
}
