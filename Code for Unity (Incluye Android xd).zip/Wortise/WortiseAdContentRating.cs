public enum WortiseAdContentRating
{
    G,
    MA,
    PG,
    T
}
