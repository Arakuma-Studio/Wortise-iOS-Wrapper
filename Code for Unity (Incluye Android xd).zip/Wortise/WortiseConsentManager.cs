﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif

public class WortiseConsentManager
{
    #if UNITY_ANDROID
    private static AndroidJavaObject activity
    {
        get
        {
            return WortiseSdk.activity;
        }
    }
    
    private static AndroidJavaObject consentManager;
    
    public static bool CanCollectData
    {
        get
        {
            if (activity != null) {
                return consentManager.CallStatic<bool>("canCollectData", activity);
            }
            
            return false;
        }
    }

    public static bool Exists
    {
        get
        {
            if (activity != null) {
                return consentManager.CallStatic<bool>("exists", activity);
            }
            
            return false;
        }
    }
    
    static WortiseConsentManager()
    {
        consentManager = new AndroidJavaClass("com.wortise.ads.consent.ConsentManager");
    }
    
    public static void Request()
    {
        if (activity != null) {
            consentManager.CallStatic("request", activity);
        }
    }
    
    public static void RequestIfRequired()
    {
        if (activity != null) {
            consentManager.CallStatic("requestIfRequired", activity);
        }
    }
    #endif

    #if UNITY_IOS
    public static void RequestIfRequired()
    {
        RequestConsentIfRequired();
    }

    [DllImport("__Internal")]
    private static extern void RequestConsentIfRequired();
    #endif
}
