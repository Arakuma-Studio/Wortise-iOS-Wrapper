public enum WortiseUserGender
{
    Female,
    Male
}
