#if UNITY_IPHONE || UNITY_IOS
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

using UnityEditor;
using UnityEditor.Callbacks;
using UnityEditor.iOS.Xcode;
using UnityEngine;

public static class AppendBuildInstructions
{
    [PostProcessBuild]
    public static void OnPostProcessBuild(BuildTarget buildTarget, string path)
    {
        string text = "HOW TO BUILD IN XCODE WITHOUT PROBLEMS: \n" +
        "1. Remove the reference to the Wortise Wrapper in the project, xcode is retarded and doesn't link it properly\n" +
        "2. Insert the reference again in Unity-iPhone, in embedded frameworks, and set it embed and sign\n" +
        "3. Insert all the internal frameworks of the Wortise Wrapper also in embedded frameworks\n" +
        "4. Insert UIKit and Foundation in linked frameworks, set them to Do not embed\n" +
        "5. Go to UnityFramework target, in embedded frameworks, add reference to the Wortise Wrapper, set it to Do Not Embed\n" +
        "6. DONE!!! :D";

        File.AppendAllText(Path.Combine(path, "README_build_instructions.txt"), text);
    }
}
#endif