using System;
using System.IO;
using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
[CustomEditor(typeof(WortiseIosSettings))]
public class WortiseIosSettingsEditor : UnityEditor.Editor
{
    SerializedProperty _appIdiOS;

    [MenuItem("Assets/WortiseIOS/Settings")]
    public static void OpenInspector()
    {
        Selection.activeObject = WortiseIosSettings.LoadInstance();
    }

    public void OnEnable()
    {
        _appIdiOS = serializedObject.FindProperty("wortiseGoogleIOSAppId");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.LabelField("Wortise iOS Settings", EditorStyles.boldLabel);
        EditorGUILayout.Space();

        EditorGUILayout.PropertyField(_appIdiOS, new GUIContent("iOS App ID"));

        serializedObject.ApplyModifiedProperties();
    }
}

internal class WortiseIosSettings : ScriptableObject
{
    private const string MobileAdsSettingsResDir = "Assets/Plugins/Wortise/iOS/Resources";
    private const string MobileAdsSettingsFile = "WortiseIosSettings";
    private const string MobileAdsSettingsFileExtension = ".asset";
    
    internal static WortiseIosSettings LoadInstance()
    {
        // Read from resources.
        var instance = Resources.Load<WortiseIosSettings>(MobileAdsSettingsFile);
        // Create instance if null.
        if (instance == null)
        {
            Directory.CreateDirectory(MobileAdsSettingsResDir);
            instance = ScriptableObject.CreateInstance<WortiseIosSettings>();
            string assetPath = Path.Combine(MobileAdsSettingsResDir,
                                            MobileAdsSettingsFile + MobileAdsSettingsFileExtension);
            AssetDatabase.CreateAsset(instance, assetPath);
            AssetDatabase.SaveAssets();
        }
        return instance;
    }

    [SerializeField]
    private string wortiseGoogleIOSAppId = string.Empty;

    public string WortiseGoogleIOSAppId
    {
        get { return wortiseGoogleIOSAppId; }
        set { wortiseGoogleIOSAppId = value; }
    }
}