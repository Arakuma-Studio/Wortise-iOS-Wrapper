#import <Foundation/Foundation.h>

// Expose UnityPause so it can be called from C#
extern void UnityPause(int pause);

#ifdef __cplusplus
extern "C"
{
#endif
void PauseUnity()
{
    UnityPause(1); // Pause Unity
}

void ResumeUnity()
{
    UnityPause(0); // Resume Unity
}
#ifdef __cplusplus
}
#endif
