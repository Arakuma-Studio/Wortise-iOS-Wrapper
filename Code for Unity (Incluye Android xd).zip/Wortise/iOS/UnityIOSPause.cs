using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;

public static class UnityIOSPause
{
    [DllImport("__Internal")]
    private static extern void PauseUnity();

    [DllImport("__Internal")]
    private static extern void ResumeUnity();

    public static void Pause()
    {
        PauseUnity();
    }

    public static void Resume()
    {
        ResumeUnity();
    }
}
#endif
