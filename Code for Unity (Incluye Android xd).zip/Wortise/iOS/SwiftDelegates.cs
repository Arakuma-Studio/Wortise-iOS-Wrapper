using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class SwiftDelegates
{
    public delegate void CallbackDelegate();
    public delegate void CallbackDelegateInt(int parameter);
    public delegate void CallbackDelegateString(string parameter);
}
