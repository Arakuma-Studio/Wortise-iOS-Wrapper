//
//  WortiseSDK.h
//  WortiseSDK
//

#import <Foundation/Foundation.h>

//! Project version number for WortiseSDK.
FOUNDATION_EXPORT double WortiseSDKVersionNumber;

//! Project version string for WortiseSDK.
FOUNDATION_EXPORT const unsigned char WortiseSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WortiseSDK/PublicHeader.h>


