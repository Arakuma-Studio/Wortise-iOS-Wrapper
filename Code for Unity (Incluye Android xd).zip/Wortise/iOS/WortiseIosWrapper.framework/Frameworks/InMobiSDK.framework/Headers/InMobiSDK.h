//
//  InMobiSDK.h
//  InMobiSDK
//
//  Copyright © 2016 InMobi. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef InMobiSDK_h
#define InMobiSDK_h

//! Project version number for InMobiSDK.
FOUNDATION_EXPORT double InMobiSDKVersionNumber;

//! Project version string for InMobiSDK.
FOUNDATION_EXPORT const unsigned char InMobiSDKVersionString[];

#import <InMobiSDK/IMODTargetingService.h>

#endif /* InMobiSDK_h */
