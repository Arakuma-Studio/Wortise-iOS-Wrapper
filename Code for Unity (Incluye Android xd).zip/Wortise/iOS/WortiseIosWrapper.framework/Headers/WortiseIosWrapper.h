//
//  WortiseIosWrapper.h
//  WortiseIosWrapper
//
//  Created by Eduard Cadena on 01/28/25.
//

#import <Foundation/Foundation.h>

//! Project version number for WortiseIosWrapper.
FOUNDATION_EXPORT double WortiseIosWrapperVersionNumber;

//! Project version string for WortiseIosWrapper.
FOUNDATION_EXPORT const unsigned char WortiseIosWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WortiseIosWrapper/PublicHeader.h>
