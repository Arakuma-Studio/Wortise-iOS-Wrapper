﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif

public class WortiseSdk
{
    #if UNITY_ANDROID
    public static AndroidJavaObject activity
    {
        get
        {
            AndroidJavaClass playerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            return playerClass.GetStatic<AndroidJavaObject>("currentActivity");
        }
    }
    
    private static AndroidJavaClass wortiseSdk;
    
    public static bool IsInitialized
    {
        get
        {
            return wortiseSdk.CallStatic<bool>("isInitialized");
        }
    }

    public static bool IsReady
    {
        get
        {
            return wortiseSdk.CallStatic<bool>("isReady");
        }
    }

    public static event Action OnInitialized;

    public static bool Version
    {
        get
        {
            return wortiseSdk.CallStatic<bool>("getVersion");
        }
    }


    static WortiseSdk()
    {
        wortiseSdk = new AndroidJavaClass("com.wortise.ads.WortiseSdk");
    }

    public static void Initialize(string assetKey)
    {
        if (activity != null) {
            wortiseSdk.CallStatic("initialize", activity, assetKey, new SdkInitializationListener());
        }
    }

    class SdkInitializationListener : AndroidJavaProxy
    {
        public SdkInitializationListener() : base("kotlin.jvm.functions.Function0")
        {
        }
        
        public AndroidJavaObject invoke()
        {
            if (OnInitialized != null) {
                OnInitialized();
            }

            return null;
        }
    }
    #endif

    #if UNITY_IOS
    public static void Initialize(string assetKey, bool testMode, string contentRating, SwiftDelegates.CallbackDelegate onInitialized)
    {
        int testModeInt = testMode ? 1 : 0;
        InitializeWortise(assetKey, testModeInt, contentRating, onInitialized);
    }

    [DllImport("__Internal")]
    private static extern void InitializeWortise(string assetKey, int testMode, string contentRating, SwiftDelegates.CallbackDelegate onInitialized);
    #endif
}
