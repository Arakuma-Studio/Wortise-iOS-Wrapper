﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif
public class WortiseInterstitial
{
    #if UNITY_ANDROID
    private static AndroidJavaObject activity
    {
        get
        {
            return WortiseSdk.activity;
        }
    }
    
    private AndroidJavaObject interstitialAd;
            
    public bool IsAvailable
    {
        get
        {
            return interstitialAd.Call<bool>("isAvailable");
        }
    }
    
    public bool IsDestroyed
    {
        get
        {
            return interstitialAd.Call<bool>("isDestroyed");
        }
    }

    public bool IsShowing
    {
        get
        {
            return interstitialAd.Call<bool>("isShowing");
        }
    }
    
    public event Action OnClicked;
    public event Action OnDismissed;
    public event Action OnFailedToLoad;
    public event Action OnFailedToShow;
    public event Action OnImpression;
    public event Action OnLoaded;
    public event Action OnShown;

    
    public WortiseInterstitial(string adUnitId)
    {
        interstitialAd = new AndroidJavaObject("com.wortise.ads.interstitial.InterstitialAd", activity, adUnitId);
        interstitialAd.Call("setListener", new InterstitialAdListener(this));
    }

    public void Destroy()
    {
        interstitialAd.Call("destroy");
    }

    public void LoadAd()
    {
        interstitialAd.Call("loadAd");
    }
    
    public void ShowAd()
    {
        if (activity != null)
        {
            interstitialAd.Call("showAd", activity);
        }
    }
    
    private class InterstitialAdListener : AndroidJavaProxy
    {
        private WortiseInterstitial interstitialAd;


        public InterstitialAdListener(WortiseInterstitial interstitialAd) : base("com.wortise.ads.interstitial.InterstitialAd$Listener")
        {
            this.interstitialAd = interstitialAd;
        }
        
        public void onInterstitialClicked(AndroidJavaObject ad)
        {
            if (interstitialAd.OnClicked != null) {
                interstitialAd.OnClicked();
            }
        }

        public void onInterstitialDismissed(AndroidJavaObject ad)
        {
            if (interstitialAd.OnDismissed != null) {
                interstitialAd.OnDismissed();
            }
        }

        public void onInterstitialFailedToLoad(AndroidJavaObject ad, AndroidJavaObject error)
        {
            Debug.Log("Failed to load interstitial ad!");
            Debug.Log("error: " + error.Call<string>("getMessage"));

            if (interstitialAd.OnFailedToLoad != null) {
                interstitialAd.OnFailedToLoad();
            }
        }

        public void onInterstitialFailedToShow(AndroidJavaObject ad, AndroidJavaObject error)
        {
            if (interstitialAd.OnFailedToShow != null) {
                interstitialAd.OnFailedToShow();
            }
        }

        public void onInterstitialImpression(AndroidJavaObject ad)
        {
            if (interstitialAd.OnImpression != null) {
                interstitialAd.OnImpression();
            }
        }

        public void onInterstitialLoaded(AndroidJavaObject ad)
        {
            if (interstitialAd.OnLoaded != null) {
                interstitialAd.OnLoaded();
            }
        }

        public void onInterstitialShown(AndroidJavaObject ad)
        {
            if (interstitialAd.OnShown != null) {
                interstitialAd.OnShown();
            }
        }
    }
    #endif

    #if UNITY_IOS
    public WortiseInterstitial(string adID, SwiftDelegates.CallbackDelegate onLoaded,
        SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onFailedToShow,
        SwiftDelegates.CallbackDelegate onDismissed)
    {
        LoadInterstitialAd(adID, onLoaded, onFailedToLoad, onFailedToShow, onDismissed);
    }

    [DllImport("__Internal")]
    private static extern void LoadInterstitialAd(string adID, SwiftDelegates.CallbackDelegate onLoaded,
        SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onFailedToShow,
        SwiftDelegates.CallbackDelegate onDismissed);

    public void ShowAd()
    {
        UnityIOSPause.Pause();
        ShowInterstitial();
    }

    [DllImport("__Internal")]
    private static extern void ShowInterstitial();

    public bool IsAvailable
    {
        get
        {
            return IsInterstitialAvailable() == 1;
        }
    }

    [DllImport("__Internal")]
    private static extern int IsInterstitialAvailable();

    #endif
}