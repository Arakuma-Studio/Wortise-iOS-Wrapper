﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif

public class WortiseAppOpen
{
    #if UNITY_ANDROID
    private static AndroidJavaObject activity
    {
        get
        {
            return WortiseSdk.activity;
        }
    }

    private AndroidJavaObject appOpenAd;

    public bool AutoReload
    {
        get
        {
            return appOpenAd.Call<bool>("getAutoReload");
        }

        set
        {
            appOpenAd.Call("setAutoReload", value);
        }
    }

    public bool IsAvailable
    {
        get
        {
            return appOpenAd.Call<bool>("isAvailable");
        }
    }
    
    public bool IsDestroyed
    {
        get
        {
            return appOpenAd.Call<bool>("isDestroyed");
        }
    }

    public bool IsShowing
    {
        get
        {
            return appOpenAd.Call<bool>("isShowing");
        }
    }

    public event Action OnClicked;
    public event Action OnDismissed;
    public event Action OnFailedToLoad;
    public event Action onFailedToShow;
    public event Action OnImpression;
    public event Action OnLoaded;
    public event Action OnShown;

    public WortiseAppOpen(string adUnitId)
    {
        appOpenAd = new AndroidJavaObject("com.wortise.ads.appopen.AppOpenAd", activity, adUnitId);
        appOpenAd.Call("setListener", new AppOpenAdListener(this));
    }
    
    public void Destroy()
    {
        appOpenAd.Call("destroy");
    }
    
    public void LoadAd(string adUnitId)
    {
        appOpenAd.Call("loadAd");
    }
    
    public void ShowAd()
    {
        if (activity != null)
        {
            appOpenAd.Call("showAd", activity);
        }
    }

    public void TryToShowAd()
    {
        appOpenAd.Call("tryToShowAd", activity);
    }

    class AppOpenAdListener : AndroidJavaProxy
    {
        private WortiseAppOpen appOpenAd;

        public AppOpenAdListener(WortiseAppOpen appOpenAd) : base("com.wortise.ads.appopen.AppOpenAd$Listener")
        {
            this.appOpenAd = appOpenAd;
        }
        
        public void onAppOpenClicked(AndroidJavaObject ad)
        {
            if (appOpenAd.OnClicked != null) {
                appOpenAd.OnClicked();
            }
        }

        public void onAppOpenDismissed(AndroidJavaObject ad)
        {
            if (appOpenAd.OnDismissed != null) {
                appOpenAd.OnDismissed();
            }
        }

        public void onAppOpenFailedToLoad(AndroidJavaObject ad, AndroidJavaObject error)
        {
            if (appOpenAd.OnFailedToLoad != null) {
                appOpenAd.OnFailedToLoad();
            }
        }

        public void onAppOpenFailedToShow(AndroidJavaObject ad, AndroidJavaObject error)
        {
            if (appOpenAd.onFailedToShow != null) {
                appOpenAd.onFailedToShow();
            }
        }

        public void onAppOpenImpression(AndroidJavaObject ad)
        {
            if (appOpenAd.OnImpression != null) {
                appOpenAd.OnImpression();
            }
        }

        public void onAppOpenLoaded(AndroidJavaObject ad)
        {
            if (appOpenAd.OnLoaded != null) {
                appOpenAd.OnLoaded();
            }
        }

        public void onAppOpenShown(AndroidJavaObject ad)
        {
            if (appOpenAd.OnShown != null) {
                appOpenAd.OnShown();
            }
        }
    }
    #endif

    #if UNITY_IOS
    public WortiseAppOpen(string adID, SwiftDelegates.CallbackDelegate onLoaded,
            SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onDismissed)
    {
        LoadAppOpen(adID, onLoaded, onFailedToLoad, onDismissed);
    }

    [DllImport("__Internal")]
    private static extern void LoadAppOpen(string adID, SwiftDelegates.CallbackDelegate onLoaded,
            SwiftDelegates.CallbackDelegate onFailedToLoad, SwiftDelegates.CallbackDelegate onDismissed);

    public void TryToShowAd()
    {
        UnityIOSPause.Pause();
        ShowAppOpen();
    }

    [DllImport("__Internal")]
    private static extern void ShowAppOpen();

    public bool IsAvailable
    {
        get
        {
            return IsAppOpenAvailable() == 1;
        }
    }

    [DllImport("__Internal")]
    private static extern int IsAppOpenAvailable();

    #endif
}

