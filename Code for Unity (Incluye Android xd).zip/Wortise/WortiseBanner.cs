using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_IOS
using System.Runtime.InteropServices;
#endif

public enum BannerPosition
{
    Top,
    Bottom
}

public class WortiseBanner
{
    #if UNITY_ANDROID
    private static AndroidJavaObject activity
    {
        get
        {
            return WortiseSdk.activity;
        }
    }
    
    private AndroidJavaObject bannerAd;

    public bool IsLoading
    {
        get
        {
            return bannerAd.Call<bool>("isLoading");
        }
    }

    public int AdHeightPx
    {
        get
        {
            return bannerAd.Call<int>("getHeight");
        }
    }

    public event Action OnClicked;
    public event Action OnFailedToLoad;
    public event Action OnImpression;
    public event Action OnLoaded;

    public WortiseBanner(string adUnitId, BannerPosition position, long autoRefreshSecs)
    {
        Rect safeArea = Screen.safeArea;
        int leftMargin = Mathf.RoundToInt(safeArea.xMin);
        int bottomMargin = Mathf.RoundToInt(safeArea.yMin); 
        int rightMargin = Mathf.RoundToInt(Screen.width - safeArea.xMax);
        int topMargin = Mathf.RoundToInt(Screen.height - safeArea.yMax);

        // Run on the UI thread
        activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
        {
            bannerAd = new AndroidJavaObject("com.wortise.ads.banner.BannerAd", activity);
            bannerAd.Call("setAdUnitId", adUnitId);

            AndroidJavaClass rClass = new AndroidJavaClass("android.R$id");
            int contentId = rClass.GetStatic<int>("content");

            AndroidJavaObject layout = activity.Call<AndroidJavaObject>("findViewById", contentId);
            layout = layout.Call<AndroidJavaObject>("getRootView");

            // Create layout parameters
            AndroidJavaObject layoutParams = new AndroidJavaObject("android.widget.FrameLayout$LayoutParams", -1, -2);

            // Set gravity to bottom or top
            int gravity = position == BannerPosition.Bottom ?
                new AndroidJavaClass("android.view.Gravity").GetStatic<int>("BOTTOM") :
                new AndroidJavaClass("android.view.Gravity").GetStatic<int>("TOP");

            layoutParams.Set("gravity", gravity);
            layoutParams.Call("setMargins", leftMargin, topMargin, rightMargin, bottomMargin);

            // Add the banner ad to the layout
            layout.Call("addView", bannerAd, layoutParams);
        
            AndroidJavaClass adSize = new AndroidJavaClass("com.wortise.ads.AdSize");
            AndroidJavaObject adSizeObj = adSize.GetStatic<AndroidJavaObject>("HEIGHT_50");

            bannerAd.Call("setAdSize", adSizeObj);
            bannerAd.Call("setListener", new BannerAdListener(this));

            if (autoRefreshSecs >= 30) bannerAd.Call("setAutoRefreshTime", autoRefreshSecs * 1000);
        }));
    }

    public void LoadAd()
    {
        bannerAd.Call("loadAd");
    }

    public void OnDestroy()
    {
        Debug.Log("OnDestroy Banner Ad");
        activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
        {
            bannerAd.Call("destroy");
            bannerAd.Call<AndroidJavaObject>("getParent").Call("removeView", bannerAd);
            bannerAd = null;

            AndroidJavaClass javaSystem = new AndroidJavaClass("java.lang.System");
            javaSystem.CallStatic("gc");
        }));
    }

    public void OnPause()
    {
        Debug.Log("OnPause Banner Ad");
        bannerAd.Call("pause");
    }

    public void OnResume()
    {
        Debug.Log("OnResume Banner Ad");
        bannerAd.Call("resume");
    }

    private class BannerAdListener : AndroidJavaProxy
    {
        private WortiseBanner bannerAd;

        public BannerAdListener(WortiseBanner bannerAd) : base("com.wortise.ads.banner.BannerAd$Listener")
        {
            this.bannerAd = bannerAd;
        }
        
        public void onBannerClicked(AndroidJavaObject ad)
        {
            if (bannerAd.OnClicked != null) {
                bannerAd.OnClicked();
            }
        }

        public void onBannerFailedToLoad(AndroidJavaObject ad, AndroidJavaObject error)
        {
            Debug.Log("Failed to load banner ad!");
            Debug.Log("error: " + error.Call<string>("getMessage"));

            if (bannerAd.OnFailedToLoad != null) {
                bannerAd.OnFailedToLoad();
            }
        }

        public void onBannerImpression(AndroidJavaObject ad)
        {
            if (bannerAd.OnImpression != null) {
                bannerAd.OnImpression();
            }
        }

        public void onBannerLoaded(AndroidJavaObject ad)
        {
            if (bannerAd.OnLoaded != null) {
                bannerAd.OnLoaded();
            }
        }
    }
    #endif

    #if UNITY_IOS

    string positionString = "TOP";

    public WortiseBanner(string adUnitId, BannerPosition position, double autoRefreshSecs,
        SwiftDelegates.CallbackDelegate onImpression, SwiftDelegates.CallbackDelegate onFailedToLoad)
    {
        positionString = position == BannerPosition.Bottom ? "BOTTOM" : "TOP";
        InitializeBanner(adUnitId, positionString, autoRefreshSecs, onImpression, onFailedToLoad);
    }

    [DllImport("__Internal")]
    private static extern void InitializeBanner(string adID, string bannerPosition, double refreshSecs,
        SwiftDelegates.CallbackDelegate onImpression, SwiftDelegates.CallbackDelegate onFailedToLoad);

    public void LoadAd()
    {
        Rect safeArea = Screen.safeArea;
        int bottomMargin = Mathf.RoundToInt(safeArea.yMin); 
        int topMargin = Mathf.RoundToInt(Screen.height - safeArea.yMax);
        int paddingPx = positionString == "TOP" ? topMargin : bottomMargin;
        LoadAndShowBanner(paddingPx);
    }

    [DllImport("__Internal")]
    private static extern void LoadAndShowBanner(int paddingPx);

    public bool IsLoading
    {
        get => IsBannerLoading();
    }

    [DllImport("__Internal")]
    private static extern bool IsBannerLoading();

    public void OnDestroy()
    {
        DestroyBanner();
    }

    [DllImport("__Internal")]
    private static extern void DestroyBanner();

    public int AdHeightPx
    {
        get => GetBannerAdPixelHeight();
    }

    [DllImport("__Internal")]
    private static extern int GetBannerAdPixelHeight();

    #endif
}
